$(".introBlock").ripples({
  resolution: 400,
  perturbance: 100,
});
$(document).ready(function($) {
  $('.workSlider').owlCarousel({
    loop: true,
    margin: 10,
    autoplay:false,
    autoplayHoverPause:true,
    // autoplayTimeout:2000,
    responsiveClass: true,
    responsive: {
      0: {
        items: 1,
        nav: false
      },
      600: {
        items: 1,
        nav: false
      },
      1000: {
        items: 1,
        nav: true,
        loop: true,
        margin: 30
      }
    }
  })
})
// $(document).ready(function($) {
//   $('.serviceSlider').owlCarousel({
//     loop: true,
//     margin: 10,
//     autoplay:true,
//     autoplayHoverPause:true,
//     // autoplayTimeout:2000,
//     responsiveClass: true,
//     responsive: {
//       0: {
//         items: 1,
//         nav: false
//       },
//       600: {
//         items: 1,
//         nav: false
//       },
//       1000: {
//         items: 1,
//         nav: false,
//         loop: true,
//         margin: 30
//       }
//     }
//   })
// })
$(window).scroll(function() {
  // var sticky = $('.header'),
    scroll = $(window).scrollTop();
   
  if (scroll >= 100) { 
    $('.header').hide();
    $('.fixedheader').show();
    $('.scrollMenu').show();
    $('.socialMenu').hide();
 }
  else { 
  $('.header').show();
  $('.fixedheader').hide();
  $('.socialMenu').show();
  $('.scrollMenu').hide();

}
});
$(function(){
    $('.btnMenu').click(function(){
        $('.liftMenu').show();
    });
    $('.menuClose').click(function(){
        $('.liftMenu').hide();
    });
});
$(function() {
    var lis = $(".leftService img"),
        active = 0;
        N = 5;//interval in seconds
    var inter = setInterval(function() {
        active = (active + 1) % lis.length;
        lis.removeClass('active').eq(active).addClass('active');
    }, N * 1000);
});
$(function() {
    var lis = $(".rightService"),
        active = 0;
        N = 5;//interval in seconds
    var inter = setInterval(function() {
        active = (active + 1) % lis.length;
        lis.removeClass('active').eq(active).addClass('active');
        $('.rightService p').slideUp(500);
        $('.rightService.active p').slideDown(500);
    }, N * 1000);
});
$(function(){
  $('.rightService h4').click(function(){
    $('.rightService').removeClass('active');
    $('.leftService img').removeClass('active');
    $('.rightService p').slideUp(500);
    $(this).parents('.rightService').addClass('active');
    $('.rightService.active p').slideDown(500);
    var index =  $(this).parents('.rightService').index();
    var indecIncr = index+1
    $('.leftService img:nth-child(' +indecIncr+ ')').addClass('active');
    clearInterval(inter);
  });
});